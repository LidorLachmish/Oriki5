# W837H — NAVAL COMMAND AUDIO SYSTEM

```
██╗    ██╗ █████╗  █████╗  ██████╗ ███████╗██╗  ██╗
██║    ██║██╔══██╗██╔══██╗╚════██╗╚════██║██║  ██║
██║ █╗ ██║╚█████╔╝╚█████╔╝ █████╔╝    ██╔╝███████║
╚██╔╝╚██╔╝██╔══██╗██╔══██╗ ╚═══██╗   ██╔╝ ██╔══██║
 ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ██████╔╝   ██║  ██║  ██║
                            ╚═════╝    ╚═╝  ╚═╝  ╚═╝
THE CLOWN BEHIND THE GUN — NAVAL COMMAND PLAYLIST
```

A premium futuristic naval command audio system dashboard built with pure HTML5, CSS3, and Vanilla JavaScript. No frameworks. No dependencies.

---

## Features

- **Full-screen military HUD interface** with your background image visible behind the dashboard
- **Animated audio spectrum visualizer** with red neon glow effects
- **5-band equalizer** (60Hz / 250Hz / 1KHz / 4KHz / 12KHz) with visual bars
- **Circular volume dial** with needle rotation
- **Playlist panel** with active track highlighting and playing animation
- **Playback controls**: Play/Pause, Next, Previous, Shuffle, Repeat
- **Seekable progress bar** with click and drag support
- **Real-time clock** and date display in the header
- **Keyboard shortcuts** for hands-free control
- **Scan-line CRT overlay** for that authentic tactical display feel

---

## Repository Structure

```
NAVAL-MUSIC-PLAYER/
│
├── index.html          ← Main dashboard
│
├── css/
│   └── style.css       ← All styles, animations, layout
│
├── js/
│   ├── app.js          ← App bootstrap & event wiring
│   ├── player.js       ← Audio engine (HTML5 Audio API)
│   └── ui.js           ← DOM updates & visualizer
│
├── assets/
│   └── background.png  ← Full-screen background image
│
├── music/
│   ├── song1.mp3       ← Add your audio files here
│   ├── song2.mp3
│   └── ...
│
└── README.md
```

---

## Installation

No installation required. This is a pure static web app.

1. Clone or download this repository
2. Drop your `.mp3` files into the `music/` folder
3. Open `index.html` in any modern browser

> **Important:** Open via a local web server (not by double-clicking the file). Browsers block local file audio for security.

### Recommended local servers

**Python (easiest):**
```bash
cd NAVAL-MUSIC-PLAYER
python3 -m http.server 8080
# Then open: http://localhost:8080
```

**Node.js (npx):**
```bash
npx serve .
```

**VS Code:** Install the "Live Server" extension, right-click `index.html` → Open with Live Server.

---

## How to Add Songs

1. Copy your `.mp3` files into the `music/` folder
2. Open `js/player.js`
3. Edit the `playlist` array:

```javascript
const playlist = [
  { title: "WAR MACHINE",     artist: "YOUR ARTIST", file: "music/song1.mp3" },
  { title: "DARK OCEAN",      artist: "YOUR ARTIST", file: "music/song2.mp3" },
  { title: "YOUR TRACK NAME", artist: "YOUR ARTIST", file: "music/yourfile.mp3" },
];
```

Each entry must have:
- `title` — Track name displayed in the playlist and now-playing area
- `artist` — Artist name
- `file` — Path relative to `index.html` (always starts with `music/`)

---

## How to Change the Background Image

1. Replace `assets/background.png` with your own image
2. Keep the filename as `background.png`, **or** update the CSS and HTML references:
   - In `css/style.css`: search for `background.png` and update the path
   - In `index.html`: the `.bg-character` element also uses it

The image is automatically blurred and darkened to remain visible but not overpower the HUD.

---

## Keyboard Shortcuts

| Key                | Action            |
|--------------------|-------------------|
| `Space`            | Play / Pause      |
| `Ctrl + →`         | Next track        |
| `Ctrl + ←`         | Previous track    |
| `↑`                | Volume up (+5)    |
| `↓`                | Volume down (-5)  |

---

## Browser Compatibility

| Browser | Support |
|---------|---------|
| Chrome 90+ | ✅ Full |
| Firefox 88+ | ✅ Full |
| Safari 15+ | ✅ Full |
| Edge 90+ | ✅ Full |

---

## Technical Notes

- **No frameworks** — pure vanilla JS ES6+
- **No CDNs** — fully offline-capable (after initial load)
- **HTML5 Audio API** — native browser audio playback
- **CSS Grid + Flexbox** — responsive layout
- **RequestAnimationFrame** — smooth 60fps visualizer
- The EQ sliders are **visual only** in this version. To add real EQ, connect a `BiquadFilterNode` chain via the Web Audio API in `player.js`.

---

*W837H — THE CLOWN BEHIND THE GUN*  
*Naval Command Playlist — All Systems Online*
