/**
 * player.js — Audio engine for the Naval Command System
 * Handles: HTML5 Audio, playback state, track management
 */

const Player = (() => {

  // ── Playlist definition ──────────────────────────────────────────
  const playlist = [
    { title: "WAR MACHINE",    artist: "UNKNOWN OPERATOR", file: "music/song1.mp3" },
    { title: "DARK OCEAN",     artist: "UNKNOWN OPERATOR", file: "music/song2.mp3" },
    { title: "BLOOD COMPASS",  artist: "UNKNOWN OPERATOR", file: "music/song3.mp3" },
    { title: "IRON TIDE",      artist: "UNKNOWN OPERATOR", file: "music/song4.mp3" },
    { title: "GHOST FREQUENCY",artist: "UNKNOWN OPERATOR", file: "music/song5.mp3" },
  ];

  // ── State ────────────────────────────────────────────────────────
  let currentIndex = 0;
  let isPlaying    = false;
  let isShuffle    = false;
  let isRepeat     = false;
  let volume       = 0.8;

  const audio = document.getElementById('audioPlayer');

  // ── Private helpers ──────────────────────────────────────────────
  function _loadTrack(index) {
    currentIndex = index;
    const track = playlist[currentIndex];
    audio.src = track.file;
    audio.load();
  }

  function _getShuffledIndex() {
    if (playlist.length <= 1) return 0;
    let idx;
    do { idx = Math.floor(Math.random() * playlist.length); }
    while (idx === currentIndex);
    return idx;
  }

  // ── Public API ───────────────────────────────────────────────────
  return {

    init() {
      audio.volume = volume;
      _loadTrack(0);

      // Auto-advance on track end
      audio.addEventListener('ended', () => {
        if (isRepeat) {
          audio.currentTime = 0;
          audio.play();
        } else {
          Player.next();
        }
      });

      // Expose events for UI
      audio.addEventListener('timeupdate',  () => Player.onTimeUpdate && Player.onTimeUpdate());
      audio.addEventListener('loadedmetadata', () => Player.onMetadata && Player.onMetadata());
      audio.addEventListener('play',  () => Player.onStateChange && Player.onStateChange(true));
      audio.addEventListener('pause', () => Player.onStateChange && Player.onStateChange(false));
      audio.addEventListener('error', () => Player.onError && Player.onError());
    },

    play() {
      if (!audio.src || audio.src === window.location.href) {
        _loadTrack(currentIndex);
      }
      return audio.play().then(() => { isPlaying = true; });
    },

    pause() {
      audio.pause();
      isPlaying = false;
    },

    togglePlay() {
      if (isPlaying) this.pause(); else this.play();
    },

    next() {
      const nextIdx = isShuffle ? _getShuffledIndex() : (currentIndex + 1) % playlist.length;
      _loadTrack(nextIdx);
      if (isPlaying) this.play();
      else isPlaying = false;
      Player.onTrackChange && Player.onTrackChange(currentIndex);
    },

    prev() {
      // If >3s in, restart track; otherwise go to previous
      if (audio.currentTime > 3) {
        audio.currentTime = 0;
      } else {
        const prevIdx = (currentIndex - 1 + playlist.length) % playlist.length;
        _loadTrack(prevIdx);
        if (isPlaying) this.play();
        Player.onTrackChange && Player.onTrackChange(currentIndex);
      }
    },

    setTrack(index) {
      const wasPlaying = isPlaying;
      _loadTrack(index);
      isPlaying = wasPlaying;
      if (wasPlaying) this.play();
      Player.onTrackChange && Player.onTrackChange(currentIndex);
    },

    seek(ratio) {
      if (audio.duration) {
        audio.currentTime = ratio * audio.duration;
      }
    },

    setVolume(val) {
      volume = Math.max(0, Math.min(1, val));
      audio.volume = volume;
    },

    toggleShuffle() {
      isShuffle = !isShuffle;
      return isShuffle;
    },

    toggleRepeat() {
      isRepeat = !isRepeat;
      return isRepeat;
    },

    // Getters
    get currentTrack() { return playlist[currentIndex]; },
    get trackIndex()   { return currentIndex; },
    get playing()      { return isPlaying; },
    get shuffleOn()    { return isShuffle; },
    get repeatOn()     { return isRepeat; },
    get volume()       { return volume; },
    get audio()        { return audio; },
    get playlist()     { return playlist; },
    get currentTime()  { return audio.currentTime || 0; },
    get duration()     { return audio.duration || 0; },
    get progress()     { return audio.duration ? audio.currentTime / audio.duration : 0; },
  };

})();
