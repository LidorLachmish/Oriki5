/**
 * app.js — Application bootstrap for Naval Command Audio System
 * Wires Player logic and UI together; handles all user interactions
 */

(function init() {

  // ── Boot ────────────────────────────────────────────────────────
  Player.init();
  UI.init();

  // Render playlist
  UI.renderPlaylist(Player.playlist, Player.trackIndex);

  // Update UI with initial track
  UI.updateTrackInfo(Player.currentTrack);

  // ── Player → UI callbacks ────────────────────────────────────────

  Player.onTimeUpdate = () => {
    UI.updateProgress(Player.currentTime, Player.duration);
  };

  Player.onMetadata = () => {
    // Update duration label in playlist row
    UI.setTrackDuration(Player.trackIndex, Player.duration);
    UI.updateProgress(Player.currentTime, Player.duration);
  };

  Player.onStateChange = (playing) => {
    UI.updatePlayButton(playing);
  };

  Player.onTrackChange = (index) => {
    UI.setActiveTrack(index, Player.playlist.length);
    UI.updateTrackInfo(Player.currentTrack);
    UI.updateProgress(0, 0);
  };

  Player.onError = () => {
    // Track file not found — show placeholder info
    UI.els.audioStatusVal.textContent = 'NO SIGNAL';
  };

  // ── Control Bar Events ────────────────────────────────────────────

  document.getElementById('playBtn').addEventListener('click', () => {
    Player.togglePlay();
  });

  document.getElementById('nextBtn').addEventListener('click', () => {
    Player.next();
  });

  document.getElementById('prevBtn').addEventListener('click', () => {
    Player.prev();
  });

  document.getElementById('shuffleBtn').addEventListener('click', () => {
    const on = Player.toggleShuffle();
    UI.updateMode(on, Player.repeatOn);
  });

  document.getElementById('repeatBtn').addEventListener('click', () => {
    const on = Player.toggleRepeat();
    UI.updateMode(Player.shuffleOn, on);
  });

  // ── Progress Bar ─────────────────────────────────────────────────

  const progressContainer = document.getElementById('progressContainer');
  let isDraggingProgress = false;

  function seekFromEvent(e) {
    const rect = progressContainer.querySelector('.progress-bar-track').getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    Player.seek(ratio);
  }

  progressContainer.addEventListener('mousedown', (e) => {
    isDraggingProgress = true;
    seekFromEvent(e);
  });

  document.addEventListener('mousemove', (e) => {
    if (isDraggingProgress) seekFromEvent(e);
  });

  document.addEventListener('mouseup', () => {
    isDraggingProgress = false;
  });

  // Touch support for progress bar
  progressContainer.addEventListener('touchstart', (e) => {
    seekFromEvent(e.touches[0]);
  }, { passive: true });

  // ── Volume Control ────────────────────────────────────────────────

  const volumeSlider = document.getElementById('volumeSlider');

  volumeSlider.addEventListener('input', () => {
    const val = parseFloat(volumeSlider.value);
    Player.setVolume(val / 100);
    UI.updateDial(val);
  });

  // Scroll volume wheel
  document.getElementById('volumeDial').addEventListener('wheel', (e) => {
    e.preventDefault();
    const current = parseFloat(volumeSlider.value);
    const next = Math.max(0, Math.min(100, current - e.deltaY * 0.3));
    volumeSlider.value = next;
    Player.setVolume(next / 100);
    UI.updateDial(next);
  }, { passive: false });

  // ── Equalizer ─────────────────────────────────────────────────────

  document.querySelectorAll('.eq-slider').forEach(slider => {
    const band = parseInt(slider.dataset.band);

    // Set visual position to match initial value
    UI.updateEQBar(band, 0);

    slider.addEventListener('input', () => {
      const val = parseFloat(slider.value);
      UI.updateEQBar(band, val);
      // Note: actual audio EQ requires Web Audio API;
      // these sliders drive the visual only in this implementation.
      // To enable real EQ: connect a BiquadFilterNode chain.
    });
  });

  // ── Playlist Clicks ───────────────────────────────────────────────

  document.getElementById('playlist').addEventListener('click', (e) => {
    const item = e.target.closest('.playlist-item');
    if (!item) return;
    const index = parseInt(item.dataset.index);
    Player.setTrack(index);
    Player.play();
  });

  // ── Nav Footer ────────────────────────────────────────────────────

  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      // For a real app, you'd show/hide panels here
      const nav = btn.dataset.nav;
      if (nav !== 'home') {
        // Briefly flash system status
        const status = document.getElementById('systemStatus');
        const orig = status.textContent;
        status.textContent = `◈ ACCESSING ${nav.toUpperCase()}...`;
        setTimeout(() => { status.textContent = orig; btn.classList.remove('active'); }, 1200);
        document.querySelector('[data-nav="home"]').classList.add('active');
      }
    });
  });

  // ── Keyboard Shortcuts ────────────────────────────────────────────

  document.addEventListener('keydown', (e) => {
    switch(e.code) {
      case 'Space':
        e.preventDefault();
        Player.togglePlay();
        break;
      case 'ArrowRight':
        if (e.ctrlKey || e.metaKey) Player.next();
        break;
      case 'ArrowLeft':
        if (e.ctrlKey || e.metaKey) Player.prev();
        break;
      case 'ArrowUp':
        e.preventDefault();
        {
          const v = Math.min(100, parseFloat(volumeSlider.value) + 5);
          volumeSlider.value = v;
          Player.setVolume(v / 100);
          UI.updateDial(v);
        }
        break;
      case 'ArrowDown':
        e.preventDefault();
        {
          const v = Math.max(0, parseFloat(volumeSlider.value) - 5);
          volumeSlider.value = v;
          Player.setVolume(v / 100);
          UI.updateDial(v);
        }
        break;
    }
  });

  // ── Boot complete log ────────────────────────────────────────────
  console.log('%cW837H — NAVAL COMMAND AUDIO SYSTEM', 'color:#cc1111;font-size:14px;font-weight:bold');
  console.log('%cAll systems online. Awaiting operator input.', 'color:#888');

})();
