/**
 * ui.js — User Interface controller for the Naval Command System
 * Handles: DOM updates, visualizer animation, clock, EQ visual
 */

const UI = (() => {

  // ── DOM refs ─────────────────────────────────────────────────────
  const $ = id => document.getElementById(id);
  const $$ = sel => document.querySelectorAll(sel);

  const els = {
    clock:          $('clock'),
    datestamp:      $('datestamp'),
    audioStatusVal: $('audioStatusVal'),
    trackTitle:     $('trackTitle'),
    trackArtist:    $('trackArtist'),
    currentTime:    $('currentTime'),
    totalDuration:  $('totalDuration'),
    progressFill:   $('progressFill'),
    progressThumb:  $('progressThumb'),
    progressCont:   $('progressContainer'),
    playIcon:       $('playIcon'),
    playBtn:        $('playBtn'),
    shuffleBtn:     $('shuffleBtn'),
    repeatBtn:      $('repeatBtn'),
    playlist:       $('playlist'),
    trackCount:     $('trackCount'),
    modeDisplay:    $('modeDisplay'),
    visualizer:     $('visualizer'),
    dialArc:        $('dialArc'),
    dialNeedle:     $('dialNeedle'),
    dialValue:      $('dialValue'),
    volumeSlider:   $('volumeSlider'),
    statusDot:      $('statusDot'),
    systemStatus:   $('systemStatus'),
  };

  // ── Visualizer state ─────────────────────────────────────────────
  const BAR_COUNT = 40;
  let vizBars = [];
  let vizAnimId = null;
  let vizPhase = 0;
  let isVisuallyPlaying = false;

  // ── EQ state ─────────────────────────────────────────────────────
  const eqValues = [0, 0, 0, 0, 0];

  // ── Helpers ──────────────────────────────────────────────────────
  function pad(n)      { return String(n).padStart(2, '0'); }
  function fmtTime(s)  {
    if (!s || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${pad(sec)}`;
  }

  // Clock ticker
  function tickClock() {
    const now = new Date();
    const h = pad(now.getHours());
    const m = pad(now.getMinutes());
    const s = pad(now.getSeconds());
    const d = pad(now.getDate());
    const mo = pad(now.getMonth() + 1);
    const y = now.getFullYear();
    els.clock.textContent     = `${h}:${m}:${s}`;
    els.datestamp.textContent = `${d}/${mo}/${y}`;
  }

  // ── Visualizer ───────────────────────────────────────────────────
  function buildVisualizer() {
    els.visualizer.innerHTML = '';
    vizBars = [];
    for (let i = 0; i < BAR_COUNT; i++) {
      const bar = document.createElement('div');
      bar.className = 'viz-bar';
      bar.style.height = '4px';
      els.visualizer.appendChild(bar);
      vizBars.push(bar);
    }
  }

  function animateVisualizer() {
    vizPhase += 0.06;
    const basePeak = isVisuallyPlaying ? 1 : 0;

    vizBars.forEach((bar, i) => {
      const pos = i / BAR_COUNT;
      // Simulate spectrum shape — peaks in mid-bass and presence
      const specShape =
        Math.exp(-Math.pow((pos - 0.15), 2) / 0.02) * 0.9 +   // bass peak
        Math.exp(-Math.pow((pos - 0.45), 2) / 0.04) * 0.6 +   // mids
        Math.exp(-Math.pow((pos - 0.75), 2) / 0.03) * 0.4 +   // highs
        0.05;

      const wave = (
        Math.sin(vizPhase * 2.1 + i * 0.35) * 0.4 +
        Math.sin(vizPhase * 1.3 + i * 0.18) * 0.3 +
        Math.sin(vizPhase * 3.7 + i * 0.55) * 0.15 +
        0.15
      );

      const height = isVisuallyPlaying
        ? Math.max(4, (wave * specShape * 65))
        : Math.max(2, Math.sin(vizPhase * 0.5 + i * 0.3) * 3 + 3);

      bar.style.height = height + 'px';

      // Color by height
      const intensity = height / 65;
      if (intensity > 0.8) {
        bar.style.background = 'linear-gradient(180deg, #ff4444 0%, #cc0000 100%)';
        bar.style.boxShadow = '0 0 8px #ff2222';
      } else if (intensity > 0.5) {
        bar.style.background = 'linear-gradient(180deg, #cc1111 0%, #880000 100%)';
        bar.style.boxShadow = '0 0 5px #cc1111';
      } else {
        bar.style.background = 'linear-gradient(180deg, #881111 0%, #550000 100%)';
        bar.style.boxShadow = 'none';
      }
    });

    vizAnimId = requestAnimationFrame(animateVisualizer);
  }

  // ── Volume dial ──────────────────────────────────────────────────
  function updateDial(value) {
    // value 0-100
    const pct = value / 100;
    // Arc: 75% of 2*PI circle, starts at 135deg
    const totalArc = 251.2 * 0.75; // 188.4
    const offset = 251.2 - (totalArc * pct) - (251.2 - totalArc); // math for the arc
    // Simpler approach
    const filled = 188.4 * pct;
    els.dialArc.style.strokeDasharray = `${filled} ${251.2 - filled}`;
    // Needle angle: from -225deg to 45deg (270 deg range)
    const angle = -225 + (270 * pct);
    els.dialNeedle.style.transform = `rotate(${angle}deg)`;
    els.dialValue.textContent = Math.round(value);
  }

  // ── EQ bars ──────────────────────────────────────────────────────
  function updateEQBar(band, value) {
    // value -12 to +12
    const fill = document.getElementById(`eqFill${band}`);
    const valEl = document.getElementById(`eqVal${band}`);
    if (!fill || !valEl) return;

    const pct = (Math.abs(value) / 12) * 50;
    if (value >= 0) {
      fill.style.bottom = '50%';
      fill.style.height = pct + '%';
      fill.style.background = 'linear-gradient(180deg, #ff1111 0%, #880000 100%)';
    } else {
      fill.style.bottom = (50 - pct) + '%';
      fill.style.height = pct + '%';
      fill.style.background = 'linear-gradient(180deg, #880000 0%, #440000 100%)';
    }
    valEl.textContent = (value > 0 ? '+' : '') + Math.round(value);
  }

  // ── Playlist rendering ───────────────────────────────────────────
  function renderPlaylist(tracks, activeIndex) {
    els.playlist.innerHTML = '';
    els.trackCount.textContent = pad(tracks.length) + ' FILES';

    tracks.forEach((track, i) => {
      const li = document.createElement('li');
      li.className = 'playlist-item' + (i === activeIndex ? ' active' : '');
      li.style.animationDelay = (i * 0.04) + 's';
      li.dataset.index = i;

      const isActive = i === activeIndex;

      li.innerHTML = `
        <div class="track-num">
          ${isActive
            ? `<div class="playing-bars"><span></span><span></span><span></span></div>`
            : pad(i + 1)
          }
        </div>
        <div class="track-info">
          <div class="track-name">${track.title}</div>
          <div class="track-artist-small">${track.artist}</div>
        </div>
        <div class="track-dur" id="dur-${i}">—:——</div>
      `;
      els.playlist.appendChild(li);
    });
  }

  function setActiveTrack(index, totalTracks) {
    $$('.playlist-item').forEach((item, i) => {
      item.classList.toggle('active', i === index);
      const numEl = item.querySelector('.track-num');
      if (i === index) {
        numEl.innerHTML = `<div class="playing-bars"><span></span><span></span><span></span></div>`;
      } else {
        numEl.textContent = pad(i + 1);
      }
    });
  }

  // ── Track info ───────────────────────────────────────────────────
  function updateTrackInfo(track) {
    els.trackTitle.textContent  = track.title;
    els.trackArtist.textContent = track.artist;
  }

  function updateProgress(currentTime, duration) {
    const pct = duration ? (currentTime / duration) * 100 : 0;
    els.currentTime.textContent   = fmtTime(currentTime);
    els.totalDuration.textContent = fmtTime(duration);
    els.progressFill.style.width  = pct + '%';
    els.progressThumb.style.left  = pct + '%';
  }

  function updatePlayButton(playing) {
    isVisuallyPlaying = playing;
    els.audioStatusVal.textContent = playing ? 'TRANSMITTING' : 'STANDBY';
    els.playIcon.innerHTML = playing
      ? `<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>`
      : `<polygon points="5,3 19,12 5,21"/>`;
  }

  function updateMode(shuffle, repeat) {
    els.shuffleBtn.classList.toggle('active', shuffle);
    els.repeatBtn.classList.toggle('active', repeat);
    let mode = 'SEQUENTIAL';
    if (shuffle && repeat) mode = 'SHUFFLE+REPEAT';
    else if (shuffle)      mode = 'SHUFFLE';
    else if (repeat)       mode = 'REPEAT';
    els.modeDisplay.textContent = mode;
  }

  function setTrackDuration(index, duration) {
    const el = document.getElementById(`dur-${index}`);
    if (el) el.textContent = fmtTime(duration);
  }

  // ── Public API ───────────────────────────────────────────────────
  return {
    els,
    fmtTime,

    init() {
      buildVisualizer();
      animateVisualizer();
      tickClock();
      setInterval(tickClock, 1000);
      updateDial(80);
    },

    renderPlaylist,
    setActiveTrack,
    updateTrackInfo,
    updateProgress,
    updatePlayButton,
    updateMode,
    updateDial,
    updateEQBar,
    setTrackDuration,

    // Progress bar seeking callback
    onProgressClick: null,
  };

})();
